<?php
try 
{
    // Codigo para experimentar

    $conexion = new PDO('mysql:host=162.241.60.84;dbname=mishelca_utez', 'mishelca_user_utez', 'mxcf2013' );
    echo "OK";
}
catch(PDOexeption $e)
{
    // Error de codigo

    echo "Error: " . $e->getMessage() ;
}

?>