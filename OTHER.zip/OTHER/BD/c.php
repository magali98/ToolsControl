<?php
try 
{
    // Codigo para experimentar

    $conexion = new PDO('mysql:host=utez:8888;dbname=utez', 'root', 'root' );
    echo "OK";
}
catch(PDOexeption $e)
{
    // Error de codigo

    echo "Error: " . $e->getMessage() ;
}

?>