<footer class="footer">
         ©  <?php echo date("Y"); ?> -- Tools Control -- <span class="text-muted d-none d-sm-inline-block float-right">Hecho con  <i class="mdi mdi-heart text-danger"></i> por Magali Miguel</span>
</footer>