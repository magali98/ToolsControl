<?php include 'layouts/header.php'; ?>

<?php include 'layouts/headerStyle.php'; ?>

    <body class="fixed-left">

        <?php include 'layouts/loader.php'; ?>

        <!-- Begin page -->
        <div id="wrapper">

            <?php include 'layouts/navbar.php'; ?>

            <!-- Start right Content here -->
            <div class="content-page">
                <!-- Start content -->
                <div class="content">

                    <!-- Top Bar Start -->
                    <div class="topbar">

                        <nav class="navbar-custom">
                            <!-- Search input -->
                            <div class="search-wrap" id="search-wrap">
                                <div class="search-bar">
                                    <input class="search-input" type="search" placeholder="Search" />
                                    <a href="#" class="close-search toggle-search" data-target="#search-wrap">
                                        <i class="mdi mdi-close-circle"></i>
                                    </a>
                                </div>
                            </div>

                            <ul class="list-inline float-right mb-0">
                                <!-- Search -->
                                <li class="list-inline-item dropdown notification-list">
                                    <a class="nav-link waves-effect toggle-search" href="#"  data-target="#search-wrap">
                                        <i class="mdi mdi-magnify noti-icon"></i>
                                    </a>
                                </li>
                                <!-- Fullscreen -->
                                <li class="list-inline-item dropdown notification-list hidden-xs-down">
                                    <a class="nav-link waves-effect" href="#" id="btn-fullscreen">
                                        <i class="mdi mdi-fullscreen noti-icon"></i>
                                    </a>
                                </li>
                                <!-- language-->
                                <li class="list-inline-item dropdown notification-list hidden-xs-down">
                                    <a class="nav-link dropdown-toggle arrow-none waves-effect text-muted" data-toggle="dropdown" href="#" role="button"
                                       aria-haspopup="false" aria-expanded="false">
                                        English <img src="public/assets/images/flags/us_flag.jpg" class="ml-2" height="16" alt=""/>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right language-switch">
                                        <a class="dropdown-item" href="#"><img src="public/assets/images/flags/germany_flag.jpg" alt="" height="16"/><span> German </span></a>
                                        <a class="dropdown-item" href="#"><img src="public/assets/images/flags/italy_flag.jpg" alt="" height="16"/><span> Italian </span></a>
                                        <a class="dropdown-item" href="#"><img src="public/assets/images/flags/french_flag.jpg" alt="" height="16"/><span> French </span></a>
                                        <a class="dropdown-item" href="#"><img src="public/assets/images/flags/spain_flag.jpg" alt="" height="16"/><span> Spanish </span></a>
                                        <a class="dropdown-item" href="#"><img src="public/assets/images/flags/russia_flag.jpg" alt="" height="16"/><span> Russian </span></a>
                                    </div>
                                </li>
                                <!-- notification-->
                                <li class="list-inline-item dropdown notification-list">
                                    <a class="nav-link dropdown-toggle arrow-none waves-effect" data-toggle="dropdown" href="#" role="button"
                                       aria-haspopup="false" aria-expanded="false">
                                        <i class="ion-ios7-bell noti-icon"></i>
                                        <span class="badge badge-danger noti-icon-badge">3</span>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right dropdown-arrow dropdown-menu-lg">
                                        <!-- item-->
                                        <div class="dropdown-item noti-title">
                                            <h5>Notification (3)</h5>
                                        </div>

                                        <!-- item-->
                                        <a href="javascript:void(0);" class="dropdown-item notify-item active">
                                            <div class="notify-icon bg-success"><i class="mdi mdi-cart-outline"></i></div>
                                            <p class="notify-details"><b>Your order is placed</b><small class="text-muted">Dummy text of the printing and typesetting industry.</small></p>
                                        </a>

                                        <!-- item-->
                                        <a href="javascript:void(0);" class="dropdown-item notify-item">
                                            <div class="notify-icon bg-warning"><i class="mdi mdi-message"></i></div>
                                            <p class="notify-details"><b>New Message received</b><small class="text-muted">You have 87 unread messages</small></p>
                                        </a>

                                        <!-- item-->
                                        <a href="javascript:void(0);" class="dropdown-item notify-item">
                                            <div class="notify-icon bg-info"><i class="mdi mdi-martini"></i></div>
                                            <p class="notify-details"><b>Your item is shipped</b><small class="text-muted">It is a long established fact that a reader will</small></p>
                                        </a>

                                        <!-- All-->
                                        <a href="javascript:void(0);" class="dropdown-item notify-item">
                                            View All
                                        </a>

                                    </div>
                                </li>
                                <!-- User-->
                                <li class="list-inline-item dropdown notification-list">
                                    <a class="nav-link dropdown-toggle arrow-none waves-effect nav-user" data-toggle="dropdown" href="#" role="button"
                                       aria-haspopup="false" aria-expanded="false">
                                        <img src="public/assets/images/users/avatar-1.jpg" alt="user" class="rounded-circle">
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right profile-dropdown ">
                                        <a class="dropdown-item" href="#"><i class="dripicons-user text-muted"></i> Profile</a>
                                        <a class="dropdown-item" href="#"><i class="dripicons-wallet text-muted"></i> My Wallet</a>
                                        <a class="dropdown-item" href="#"><span class="badge badge-success pull-right m-t-5">5</span><i class="dripicons-gear text-muted"></i> Settings</a>
                                        <a class="dropdown-item" href="#"><i class="dripicons-lock text-muted"></i> Lock screen</a>
                                        <div class="dropdown-divider"></div>
                                        <a class="dropdown-item" href="#"><i class="dripicons-exit text-muted"></i> Logout</a>
                                    </div>
                                </li>
                            </ul>

                            <!-- Page title -->
                            <ul class="list-inline menu-left mb-0">
                                <li class="list-inline-item">
                                    <button type="button" class="button-menu-mobile open-left waves-effect">
                                        <i class="ion-navicon"></i>
                                    </button>
                                </li>
                                <li class="hide-phone list-inline-item app-search">
                                    <h3 class="page-title">Ion Icons</h3>
                                </li>
                            </ul>

                            <div class="clearfix"></div>
                        </nav>

                    </div>
                    <!-- Top Bar End -->

                    <!-- ==================
                         PAGE CONTENT START
                         ================== -->

                    <div class="page-content-wrapper">

                        <div class="container-fluid">

                            <div class="row">
                                <div class="col-12">
                                    <div class="card m-b-20">
                                        <div class="card-body">

                                            <h4 class="mt-0 header-title">Examples</h4>
                                            <p class="text-muted m-b-30 font-14">Use <code>&lt;i class="ion-ionic"&gt;&lt;/i&gt;</code>.
                                            </p>

                                            <div class="row icon-demo-content">

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ionic"></i>ion-ionic
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-arrow-up-a"></i>ion-arrow-up-a
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-arrow-right-a"></i>ion-arrow-right-a
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-arrow-down-a"></i>ion-arrow-down-a
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-arrow-left-a"></i>ion-arrow-left-a
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-arrow-up-b"></i>ion-arrow-up-b
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-arrow-right-b"></i>ion-arrow-right-b
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-arrow-down-b"></i>ion-arrow-down-b
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-arrow-left-b"></i>ion-arrow-left-b
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-arrow-up-c"></i>ion-arrow-up-c
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-arrow-right-c"></i>ion-arrow-right-c
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-arrow-down-c"></i>ion-arrow-down-c
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-arrow-left-c"></i>ion-arrow-left-c
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-arrow-return-right"></i>ion-arrow-return-right
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-arrow-return-left"></i>ion-arrow-return-left
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-arrow-swap"></i>ion-arrow-swap
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-arrow-shrink"></i>ion-arrow-shrink
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-arrow-expand"></i>ion-arrow-expand
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-arrow-move"></i>ion-arrow-move
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-arrow-resize"></i>ion-arrow-resize
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-chevron-up"></i>ion-chevron-up
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-chevron-right"></i>ion-chevron-right
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-chevron-down"></i>ion-chevron-down
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-chevron-left"></i>ion-chevron-left
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-navicon-round"></i>ion-navicon-round
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-navicon"></i>ion-navicon
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-drag"></i>ion-drag
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-log-in"></i>ion-log-in
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-log-out"></i>ion-log-out
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-checkmark-round"></i>ion-checkmark-round
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-checkmark"></i>ion-checkmark
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-checkmark-circled"></i>ion-checkmark-circled
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-close-round"></i>ion-close-round
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-close"></i>ion-close
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-close-circled"></i>ion-close-circled
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-plus-round"></i>ion-plus-round
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-plus"></i>ion-plus
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-plus-circled"></i>ion-plus-circled
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-minus-round"></i>ion-minus-round
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-minus"></i>ion-minus
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-minus-circled"></i>ion-minus-circled
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-information"></i>ion-information
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-information-circled"></i>ion-information-circled
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-help"></i>ion-help
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-help-circled"></i>ion-help-circled
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-help-buoy"></i>ion-help-buoy
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-asterisk"></i>ion-asterisk
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-alert"></i>ion-alert
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-alert-circled"></i>ion-alert-circled
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-refresh"></i>ion-refresh
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-loop"></i>ion-loop
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-shuffle"></i>ion-shuffle
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-home"></i>ion-home
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-search"></i>ion-search
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-flag"></i>ion-flag
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-star"></i>ion-star
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-heart"></i>ion-heart
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-heart-broken"></i>ion-heart-broken
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-gear-a"></i>ion-gear-a
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-gear-b"></i>ion-gear-b
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-toggle-filled"></i>ion-toggle-filled
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-toggle"></i>ion-toggle
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-settings"></i>ion-settings
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-wrench"></i>ion-wrench
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-folder"></i>ion-folder
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-hammer"></i>ion-hammer
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-edit"></i>ion-edit
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-trash-a"></i>ion-trash-a
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-trash-b"></i>ion-trash-b
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-document"></i>ion-document
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-document-text"></i>ion-document-text
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-clipboard"></i>ion-clipboard
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-scissors"></i>ion-scissors
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-funnel"></i>ion-funnel
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-bookmark"></i>ion-bookmark
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-email"></i>ion-email
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-folder"></i>ion-folder
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-filing"></i>ion-filing
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-archive"></i>ion-archive
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-reply"></i>ion-reply
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-reply-all"></i>ion-reply-all
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-forward"></i>ion-forward
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-share"></i>ion-share
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-paper-airplane"></i>ion-paper-airplane
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-link"></i>ion-link
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-paperclip"></i>ion paperclip
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-compose"></i>ion-compose
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-briefcase"></i>ion-briefcase
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-medkit"></i>ion-medkit
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-at"></i>ion-at
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-pound"></i>ion-pound
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-quote"></i>ion-quote
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-cloud"></i>ion-cloud
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-upload"></i>ion-upload
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-more"></i>ion-more
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-grid"></i>ion-grid
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-calendar"></i>ion-calendar
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-clock"></i>ion-clock
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-compass"></i>ion-compass
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-pinpoint"></i>ion-pinpoint
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-pin"></i>ion-pin
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-navigate"></i>ion-navigate
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-location"></i>ion-location
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-map"></i>ion-map
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-model-s"></i>ion-model-s
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-locked"></i>ion-locked
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-unlocked"></i>ion-unlocked
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-key"></i>ion-key
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-arrow-graph-up-right"></i>ion-arrow-graph-up-right
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-arrow-graph-down-right"></i>ion-arrow-graph-down-right
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-arrow-graph-down-left"></i>ion-arrow-graph-down-left
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-stats-bars"></i>ion-stats-bars
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-connection-bars"></i>ion-connection-bars
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-pie-graph"></i>ion-pie-graph
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-chatbubble"></i>ion-chatbubble
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-chatbubble-working"></i>ion-chatbubble-working
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-chatbubbles"></i>ion-chatbubbles
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-chatbox"></i>ion-chatbox
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-chatbox-working"></i>ion-chatbox-working
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-chatboxes"></i>ion-chatboxes
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-person"></i>ion-person
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-person-add"></i>ion-person-add
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-person-stalker"></i>ion-person-stalker
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-woman"></i>ion-woman
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-man"></i>ion-man
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-female"></i>ion-female
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-male"></i>ion-male
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-fork"></i>ion-fork
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-knife"></i>ion-knife
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-spoon"></i>ion-spoon
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-beer"></i>ion-beer
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-wineglass"></i>ion-wineglass
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-coffee"></i>ion-coffee
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-icecream"></i>ion-icecream
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-pizza"></i>ion-pizza
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-power"></i>ion-power
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-mouse"></i>ion-mouse
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-battery-full"></i>ion-battery-full
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-battery-half"></i>ion-battery-half
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-battery-low"></i>ion-battery-low
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-battery-empty"></i>ion-battery-empty
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-battery-charging"></i>ion-battery-charging
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-wifi"></i>ion-wifi
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-bluetooth"></i>ion-bluetooth
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-calculator"></i>ion-calculator
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-camera"></i>ion-camera
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-eye"></i>ion-eye
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-eye-disabled"></i>ion-eye-disabled
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-flash"></i>ion-flash
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-flash-off"></i>ion-flash-off
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-qr-scanner"></i>ion-qr-scanner
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-image"></i>ion-image
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-images"></i>ion-images
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-contrast"></i>ion-contrast
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-wand"></i>ion-wall
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-aperture"></i>ion-aperture
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-monitor"></i>ion-monitor
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-laptop"></i>ion-laptop
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ipad"></i>ion-ipad
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-iphone"></i>ion-iphone
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ipod"></i>ion-ipod
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-printer"></i>ion-printer
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-usb"></i>ion-usb
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-outlet"></i>ion-outlet
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-bug"></i>ion-bug
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-code"></i>ion-code
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-code-working"></i>ion-code-working
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-code-download"></i>ion-code-download
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-fork-repo"></i>ion-fork-repo
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-network"></i>ion-network
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-pull-request"></i>ion-pull-request
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-merge"></i>ion-go
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-game-controller-a"></i>ion-game-controller-a
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-game-controller-b"></i>ion-game-controller-b
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-xbox"></i>ion-xbox
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-playstation"></i>ion-playstation
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-steam"></i>ion-steam
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-closed-captioning"></i>ion-closed-captioning
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-videocamera"></i>ion-camera
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-film-marker"></i>ion-film-marker
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-disc"></i>ion-disc
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-headphone"></i>ion-headphone
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-music-note"></i>ion-music-note
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-radio-waves"></i>ion-radio-waves
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-speakerphone"></i>ion-speakerphone
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-mic-a"></i>ion-mic-a
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-mic-b"></i>ion-mic-b
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-mic-c"></i>ion-mic-c
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-volume-high"></i>ion-volume-high
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-volume-medium"></i>ion-volume-medium
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-volume-low"></i>ion-volume-low
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-volume-mute"></i>ion-volume-mute
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-levels"></i>ion-levels
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-play"></i>ion-play
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-pause"></i>ion-pause
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-stop"></i>ion-stop
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-record"></i>ion-record
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-skip-forward"></i>ion-skip-forward
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-skip-backward"></i>ion-skip-backward
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-eject"></i>ion-eject
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-bag"></i>ion-bag
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-card"></i>ion-card
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-cash"></i>ion-cash
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-pricetag"></i>ion-pricetag
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-pricetags"></i>ion-pricetags
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-thumbsup"></i>ion-thumbsup
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-thumbsdown"></i>ion-thumbsdown
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-happy"></i>ion-happy
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-sad"></i>ion-sad
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-trophy"></i>ion-trophy
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-podium"></i>ion-podium
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ribbon-a"></i>ion-ribbon-a
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ribbon-b"></i>ion-ribbon-b
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-university"></i>ion-university
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-magnet"></i>ion-magnet
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-beaker"></i>ion-beaker
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-flask"></i>ion-flask
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-egg"></i>ion-egg
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-earth"></i>ion-earth
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-planet"></i>ion-planet
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-lightbulb"></i>ion-lightbulb
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-cube"></i>ion-cube
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-leaf"></i>ion-leaf
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-waterdrop"></i>ion-waterdrop
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-flame"></i>ion-flame
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-fireball"></i>ion-fireball
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-bonfire"></i>ion-bonfire
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-umbrella"></i>ion-umbrella
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-nuclear"></i>ion-nuclear
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-no-smoking"></i>ion-no-smoking
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-thermometer"></i>ion-thermometer
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-speedometer"></i>ion-speedometer
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-plane"></i>ion-plane
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-jet"></i>ion-jet
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-load-a"></i>ion-load-a
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-load-b"></i>ion-load-b
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-load-c"></i>ion-load-c
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-load-d"></i>ion-load-d
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-ionic-outline"></i>ion-ios7-ionic-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-arrow-back"></i>ion-ios7-arrow-back
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-arrow-forward"></i>ion-ios7-arrow-forward
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-arrow-up"></i>ion-ios7-arrow-up
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-arrow-right"></i>ion-ios7-arrow-right
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-arrow-down"></i>ion-ios7-arrow-down
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-arrow-left"></i>ion-ios7-arrow-left
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-arrow-thin-up"></i>ion-ios7-arrow-thin-up
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-arrow-thin-right"></i>ion-ios7-arrow-thin-right
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-arrow-thin-down"></i>ion-ios7-arrow-thin-down
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-arrow-thin-left"></i>ion-ios7-arrow-thin-left
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-circle-filled"></i>ion-ios7-circle-filled
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-circle-outline"></i>ion-ios7-circle-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-checkmark-empty"></i>ion-ios7-checkmark-empty
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-checkmark-outline"></i>ion-ios7-checkmark-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-checkmark"></i>ion-ios7-checkmark
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-plus-empty"></i>ion-ios7-plus-empty
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-plus-outline"></i>ion-ios7-plus-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-plus"></i>ion-ios7 more
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-close-empty"></i>ion-ios7-close-empty
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-close-outline"></i>ion-ios7-close-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-close"></i>ion-ios7-close
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-minus-empty"></i>ion-ios7-minus-empty
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-minus-outline"></i>ion-ios7-minus-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-minus"></i>ion-ios7-minus
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-information-empty"></i>ion-ios7-information-empty
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-information-outline"></i>ion-ios7-information-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-information"></i>ion-ios7-information
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-help-empty"></i>ion-ios7-help-empty
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-help-outline"></i>ion-ios7-help-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-help"></i>ion-ios7-help
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-search"></i>ion-ios7-search
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-search-strong"></i>ion-ios7-search-strong
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-star"></i>ion-ios7-star
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-star-half"></i>ion-ios7-star-half
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-star-outline"></i>ion-ios7-star-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-heart"></i>ion-ios7-heart
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-heart-outline"></i>ion-ios7-heart-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-more"></i>ion-ios7-more
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-more-outline"></i>ion-ios7-more-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-home"></i>ion-ios7-home
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-home-outline"></i>ion-ios7-home-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-cloud"></i>ion-ios7-cloud
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-cloud-outline"></i>ion-ios7-cloud-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-cloud-upload"></i>ion-ios7-cloud-upload
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-cloud-upload-outline"></i>ion-ios7-cloud-upload-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-cloud-download"></i>ion-ios7-cloud-download
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-cloud-download-outline"></i>ion-ios7-cloud-download-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-upload"></i>ion-ios7-upload
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-upload-outline"></i>ion-ios7-upload-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-download"></i>ion-ios7-download
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-download-outline"></i>ion-ios7-download-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-refresh"></i>ion-ios7-refresh
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-refresh-outline"></i>ion-ios7-refresh-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-refresh-empty"></i>ion-ios7-refresh-empty
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-reload"></i>ion-ios7-reload
                                                </div>


                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-loop-strong"></i>ion-ios7-loop-strong
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-loop"></i>ion-ios7-loop
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-bookmarks"></i>ion-ios7-bookmarks
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-bookmarks-outline"></i>ion-ios7-bookmarks-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-flag"></i>ion-ios7-flag
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-flag-outline"></i>ion-ios7-flag-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-glasses"></i>ion-ios7-glasses
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-glasses-outline"></i>ion-ios7-glasses-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-browsers"></i>ion-ios7-browsers
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-browsers-outline"></i>ion-ios7-browsers-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-at"></i>ion-ios7-at
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-at-outline"></i>ion-ios7-at-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-cart"></i>ion-ios7-cart
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-cart-outline"></i>ion-ios7-cart-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-pricetag"></i>ion-ios7-pricetag
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-pricetag-outline"></i>ion-ios7-pricetag-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-pricetags"></i>ion-ios7-pricetags
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-pricetags-outline"></i>ion-ios7-pricetags-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-chatboxes"></i>ion-ios7-chatboxes
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-chatboxes-outline"></i>ion-ios7-chatboxes-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-chatbubble"></i>ion-ios7-chatbubble
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-chatbubble-outline"></i>ion-ios7-chatbubble-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-cog"></i>ion-ios7-cog
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-cog-outline"></i>ion-ios7-cog-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-gear"></i>ion-ios7-gear
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-gear-outline"></i>ion-ios7-gear-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-settings"></i>ion-ios7-settings
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-settings-strong"></i>ion-ios7-settings-strong
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-toggle"></i>ion-ios7-toggle
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-toggle-outline"></i>ion-ios7-toggle-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-analytics"></i>ion-ios7-analytics
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-analytics-outline"></i>ion-ios7-analytics-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-pie"></i>ion-ios7-pie
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-pie-outline"></i>ion-ios7-pie-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-pulse"></i>ion-ios7-pulse
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-pulse-strong"></i>ion-ios7-pulse-strong
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-filing"></i>ion-ios7-filing
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-filing-outline"></i>ion-ios7-filing-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-box"></i>ion-ios7-box
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-box-outline"></i>ion-ios7-box-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-compose"></i>ion-ios7-compose
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-compose-outline"></i>ion-ios7-compose-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-trash"></i>ion-ios7-trash
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-trash-outline"></i>ion-ios7-trash-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-copy"></i>ion-ios7-copy
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-copy-outline"></i>ion-ios7-copy-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-email"></i>ion-ios7-email
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-email-outline"></i>ion-ios7-email-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-undo"></i>ion-ios7-undo
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-undo-outline"></i>ion-ios7-undo-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-redo"></i>ion ios7-ready
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-redo-outline"></i>ion-ios7-redo-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-redo-outline"></i>ion-ios7-redo-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-paperplane"></i>ion-ios7-paperplane
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-paperplane-outline"></i>ion-ios7-paperplane-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-folder"></i>ion-ios7-folder
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-folder-outline"></i>ion-ios7-folder-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-paper"></i>ion-ios7-paper
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-paper-outline"></i>ion-ios7-paper-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-world"></i>ion-ios7-world
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-world-outline"></i>ion-ios7-world-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-alarm"></i>ion-ios7-alarm
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-alarm-outline"></i>ion-ios7-alarm-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-speedometer"></i>ion-ios7-speedometer
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-speedometer-outline"></i>ion-ios7-speedometer-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-stopwatch"></i>ion-ios7-stopwatch
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-stopwatch-outline"></i>ion-ios7-stopwatch-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-timer"></i>ion-ios7-timer
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-timer-outline"></i>ion-ios7-timer-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-clock"></i>ion-ios7-clock
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-clock-outline"></i>ion-ios7-clock-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-time"></i>ion-ios7-time
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-time-outline"></i>ion-ios7-time-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-calendar"></i>ion-ios7-calendar
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-calendar-outline"></i>ion-ios7-calendar-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-photos"></i>ion-ios7-photos
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-photos-outline"></i>ion-ios7-photos-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-albums"></i>ion-ios7-albums
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-albums-outline"></i>ion-ios7-albums-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-camera"></i>ion-ios7-camera
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-camera-outline"></i>ion-ios7-camera-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-reverse-camera"></i>ion-ios7-reverse-camera
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-reverse-camera-outline"></i>ion-ios7-reverse-camera-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-eye"></i>ion-ios7-eye
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-eye-outline"></i>ion-ios7-eye-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-bolt"></i>ion-ios7-bolt
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-bolt-outline"></i>ion-ios7-bolt-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-barcode"></i>ion-ios7-barcode
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-barcode-outline"></i>ion-ios7-barcode-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-briefcase"></i>ion-ios7-briefcase
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-briefcase-outline"></i>ion-ios7-briefcase-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-medkit"></i>ion-ios7-medkit
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-medkit-outline"></i>ion-ios7-medkit-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-infinite"></i>ion-ios7-infinite
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-infinite-outline"></i>ion-ios7-infinite-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-calculator"></i>ion-ios7-calculator
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-calculator-outline"></i>ion-ios7-calculator-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-keypad"></i>ion-ios7-keypad
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-keypad-outline"></i>ion-ios7-keypad-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-telephone"></i>ion-ios7-telephone
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-telephone-outline"></i>ion-ios7-telephone-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-drag"></i>ion-ios7-drag
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-location"></i>ion-ios7-location
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-location-outline"></i>ion-ios7-location-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-navigate"></i>ion-ios7-navigate
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-navigate-outline"></i>ion-ios7-navigate-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-locked"></i>ion-ios7-locked
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-locked-outline"></i>ion-ios7-locked-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-unlocked"></i>ion-ios7-unlocked
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-unlocked-outline"></i>ion-ios7-unlocked-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-monitor"></i>ion-ios7-monitor
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-monitor-outline"></i>ion-ios7-monitor-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-printer"></i>ion-ios7-printer
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-printer-outline"></i>ion-ios7-printer-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-person"></i>ion-ios7-person
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-person-outline"></i>ion-ios7-person-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-personadd"></i>ion-ios7-personadd
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-personadd-outline"></i>ion-ios7-personadd-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-people"></i>ion-ios7-people
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-people-outline"></i>ion-ios7-people-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-tennisball"></i>ion ios7-tennis ball
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-tennisball-outline"></i>ion ios7 tennis ball outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-baseball"></i>ion-ios7-baseball
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-baseball-outline"></i>ion-ios7-baseball-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-basketball"></i>ion-ios7-basketball
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-basketball-outline"></i>ion-ios7-basketball-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-football"></i>ion-ios7-football
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-football-outline"></i>ion-ios7-football-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-americanfootball"></i>ion-ios7-americanfootball
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-americanfootball-outline"></i>ion-ios7-americanfootball-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-paw"></i>ion-ios7-paw
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-paw-outline"></i>ion-ios7-paw-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-sunny"></i>ion-ios7-sunny
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-sunny-outline"></i>ion-ios7-sunny-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-partlysunny"></i>ion-ios7-partlysunny
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-partlysunny-outline"></i>ion-ios7-partlysunny-Outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-cloudy"></i>ion-ios7-cloudy
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-cloudy-outline"></i>ion-ios7-cloudy-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-rainy"></i>ion-ios7-rainy
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-rainy-outline"></i>ion-ios7-rainy-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-thunderstorm"></i>ion-ios7-thunderstorm
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-thunderstorm-outline"></i>ion-ios7-thunderstorm-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-snowy"></i>ion-ios7-snowy
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-moon"></i>ion-ios7-moon
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-moon-outline"></i>ion-ios7-moon-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-cloudy-night"></i>ion-ios7-cloudy-night
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-cloudy-night-outline"></i>ion-ios7-cloudy-night-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-musical-notes"></i>ion-ios7-musical-notes
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-musical-note"></i>ion-ios7-musical-note
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-bell"></i>ion-ios7-bell
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-bell-outline"></i>ion-ios7-bell-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-mic"></i>ion-ios7-small
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-mic-outline"></i>ion-ios7-mic-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-mic-off"></i>ion-ios7-mic-off
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-volume-high"></i>ion-ios7-volume-high
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-volume-low"></i>ion-ios7-volume-low
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-play"></i>ion-ios7-play
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-play-outline"></i>ion-ios7-play-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-pause"></i>ion-ios7-pause
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-pause-outline"></i>ion-ios7-pause-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-recording"></i>ion-ios7-recording
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-recording-outline"></i>ion-ios7-recording-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-fastforward"></i>ion-iOS7-FastForward
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-fastforward-outline"></i>ion-iOS7-FastForward-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-rewind"></i>ion-ios7-rewind
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-rewind-outline"></i>ion-ios7-rewind-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-skipbackward"></i>ion-ios7-skipbackward
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-skipbackward-outline"></i>ion-ios7-skipbackward-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-skipforward"></i>ion-ios7-skipforward
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-skipforward-outline"></i>ion-ios7-skipforward-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-videocam"></i>ion-iOS7-videocam
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-videocam-outline"></i>ion-ios7-videocam-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-film"></i>ion-ios7-film
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-film-outline"></i>ion-ios7-film-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-lightbulb"></i>ion-ios7-lightbulb
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-lightbulb-outline"></i>ion-ios7-lightbulb-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-wineglass"></i>ion-ios7-wineglass
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-ios7-wineglass-outline"></i>ion-ios7-wineglass-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-system-back"></i>ion-android-system-back
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-system-home"></i>ion-android-system-home
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-system-windows"></i>ion-android-system-windows
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-wifi"></i>ion-android-wifi
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-battery"></i>ion-android-battery
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-storage"></i>ion-android-storage
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-keypad"></i>ion-android-keypad
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-call"></i>ion-android-call
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-arrow-back"></i>ion-android-arrow-back
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-arrow-forward"></i>ion-android-arrow-forward
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-arrow-up-right"></i>ion-android-arrow-up-right
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-arrow-down-right"></i>ion-android-arrow-down-right
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-arrow-down-left"></i>ion-android-arrow-down-left
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-arrow-up-left"></i>ion-android-arrow-up-left
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-sort"></i>ion-android-sort
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-drawer"></i>ion-android-drawer
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-stair-drawer"></i>ion-android-stair-drawer
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-more"></i>ion-android-more
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-dropdown"></i>ion-android-dropdown
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-settings"></i>ion-android-settings
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-mixer"></i>ion-android-mixer
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-display"></i>ion-android-display
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-star"></i>ion-android-star
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-search"></i>ion-android-search
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-microphone"></i>ion-android-microphone
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-checkmark"></i>ion-android-checkmark
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-information"></i>ion-android-information
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-add"></i>ion-android-add
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-remove"></i>ion-android-remove
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-close"></i>ion-android-close
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-trash"></i>ion-android-trash
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-volume"></i>ion-android-volume
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-printer"></i>ion-android-printer
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-download"></i>ion-android-download
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-hand"></i>ion-android-hand
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-developer"></i>ion-android-developer
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-calendar"></i>ion-android-calendar
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-clock"></i>ion-android-clock
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-alarm"></i>ion-android-alarm
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-stopwatch"></i>ion-android-stopwatch
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-data"></i>ion-android-data
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-timer"></i>ion-android-timer
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-camera"></i>ion-android-camera
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-image"></i>ion-android-image
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-location"></i>ion-android-location
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-locate"></i>ion-android-locate
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-earth"></i>ion-android-earth
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-book"></i>ion-android-book
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-note"></i>ion-android-note
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-promotion"></i>ion-android-promotion
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-playstore"></i>ion-android-playstore
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-share"></i>ion-android-share
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-send"></i>ion-android-send
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-mail"></i>ion-android-mail
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-inbox"></i>ion-android-inbox
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-archive"></i>ion-android-archive
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-folder"></i>ion-android-folder
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-forums"></i>ion-android-forums
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-chat"></i>ion-android-chat
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-user-menu"></i>ion-android-user-menu
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-contact"></i>ion-android-contact
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-contacts"></i>ion-android-contacts
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-friends"></i>ion-android-friends
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-add-contact"></i>ion-android-add-contact
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-social-user"></i>ion-android-social-user
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-social"></i>ion-android-social
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-reminder"></i>ion-android-reminder
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-android-lightbulb"></i>ion-android-lightbulb
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-social-twitter"></i>ion-social-twitter
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-social-twitter-outline"></i>ion-social-twitter-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-social-facebook"></i>ion-social-facebook
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-social-facebook-outline"></i>ion-social-facebook-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-social-googleplus"></i>ion-social-googleplus
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-social-googleplus-outline"></i>ion-social-googleplus-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-social-google"></i>ion-social-google
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-social-google-outline"></i>ion-social-google-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-social-dribbble"></i>ion-social-dribbble
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-social-dribbble-outline"></i>ion-social-dribbble-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-social-github"></i>ion-social-github
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-social-github-outline"></i>ion-social-github-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-social-instagram"></i>ion-social-instagram
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-social-instagram-outline"></i>ion-social-instagram-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-social-foursquare"></i>ion-social-foursquare
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-social-foursquare-outline"></i>ion-social-foursquare-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-social-pinterest"></i>ion-social-pinterest
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-social-pinterest-outline"></i>ion-social-pinterest-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-social-rss"></i>ion-social-rss
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-social-rss-outline"></i>ion-social-rss-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-social-tumblr"></i>ion-social-tumblr
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-social-tumblr-outline"></i>ion-social-tumblr-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-social-wordpress"></i>ion-social-wordpress
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-social-wordpress-outline"></i>ion-social-wordpress-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-social-reddit"></i>ion-social-reddit
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-social-reddit-outline"></i>ion-social-reddit-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-social-hackernews"></i>ion-social-hackernews
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-social-hackernews-outline"></i>ion-social-hackernews-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-social-designernews"></i>ion-social-designernews
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-social-designernews-outline"></i>ion-social-designernews-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-social-yahoo"></i>ion-social-yahoo
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-social-yahoo-outline"></i>ion-social-yahoo-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-social-buffer"></i>ion-social-buffer
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-social-buffer-outline"></i>ion-social-buffer-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-social-skype"></i>ion-social-skype
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-social-skype-outline"></i>ion-social-skype-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-social-linkedin"></i>ion-social-linkedin
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-social-linkedin-outline"></i>ion-social-linkedin-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-social-usd"></i>ion-social-usd
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-social-usd-outline"></i>ion-social-usd-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-social-bitcoin"></i>ion-social-bitcoin
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-social-bitcoin-outline"></i>ion-social-bitcoin-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-social-vimeo"></i>ion-social-vimeo
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-social-vimeo-outline"></i>ion-social-vimeo-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-social-youtube"></i>ion-social-youtube
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-social-youtube-outline"></i>ion-social-youtube-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-social-dropbox"></i>ion-social-dropbox
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-social-dropbox-outline"></i>ion-social-dropbox-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-social-apple"></i>ion-social-apple
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-social-apple-outline"></i>ion-social-apple-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-social-android"></i>ion-social-android
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-social-android"></i>ion-social-android-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-social-windows"></i>ion-social-windows
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-social-windows-outline"></i>ion-social-windows-outline
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-social-tux"></i>ion-social-tux
                                                </div>

                                                <div class="col-xl-3 col-md-4 col-sm-6"><i class="ion-social-freebsd-devil"></i>ion-social-freebsd-devil
                                                </div>

                                            </div> <!-- End row -->

                                        </div>
                                    </div>
                                </div> <!-- end col -->
                            </div> <!-- end row -->

                        </div><!-- container -->

                    </div> <!-- Page content Wrapper -->

                </div> <!-- content -->

                <?php include 'layouts/footer.php'; ?>

            </div>
            <!-- End Right content here -->

        </div>
        <!-- END wrapper -->

        <?php include 'layouts/footerScript.php'; ?>
        
        <!-- App js -->
        <script src="public/assets/js/app.js"></script>

    </body>
</html>